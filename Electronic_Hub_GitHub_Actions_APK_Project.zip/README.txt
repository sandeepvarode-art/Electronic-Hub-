Electronic Hub Billing - Android Studio Project

How to build APK:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be generated under:
   app/build/outputs/apk/debug/

The original web billing files are packaged under:
app/src/main/assets/web/
