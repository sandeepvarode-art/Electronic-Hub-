# Electronic Hub Billing — Phone APK Build

This project is ready for GitHub Actions.

## Phone-only steps
1. Create a GitHub repository.
2. Upload ALL files from this project, including the `.github` folder.
3. Open **Actions**.
4. Select **Build Electronic Hub APK**.
5. Tap **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run.
8. Under **Artifacts**, download `Electronic-Hub-Billing-APK`.
9. Extract the artifact ZIP and install `app-debug.apk`.

No Android Studio is required.
