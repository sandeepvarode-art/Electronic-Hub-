ELECTRONIC HUB - OFFLINE BILLING SOFTWARE

Shop:
ELECTRONIC HUB
36/254
PALAKKAD-679102
9567875188

FEATURES
- Works offline in a browser
- Product and stock management
- New bills with automatic bill numbers
- Customer details
- Cash / UPI / Card / Other payment
- Bill history
- Sales reports
- Backup JSON and CSV export
- A4 browser printing
- Thermal printing is supported through the browser/printer driver
- Settings and optional GSTIN/UPI ID
- Responsive mobile layout

HOW TO USE
1. Extract the ZIP.
2. Open index.html in Chrome/Edge.
3. Add products in Products.
4. Create bills in New Bill.
5. Click Save Bill, then Print Bill.
6. Use Settings to change shop information.

IMPORTANT
Data is stored locally in the browser on the device. Clear browser data or changing browser/profile can remove access to local data. Use Backup regularly.
This is an offline billing/POS starter and does not automatically handle legal GST invoice compliance for every jurisdiction. Configure GSTIN/tax details as appropriate.
